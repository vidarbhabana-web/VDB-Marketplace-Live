package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.viewmodel.VdbViewModel

@Composable
fun CustomerScreen(
    viewModel: VdbViewModel,
    modifier: Modifier = Modifier
) {
    val activeTab by viewModel.currentCustomerTab.collectAsState()
    val walletProfile by viewModel.customerProfile.collectAsState()

    Column(modifier = modifier.fillMaxSize()) {
        // --- CUSTOMER TOP BANNER & WALLET PREVIEW ---
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            shape = RoundedCornerShape(0.dp, 0.dp, 16.dp, 16.dp),
            elevation = CardDefaults.cardElevation(4.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Vidarbha Digital Bajaar",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.LocationOn,
                                contentDescription = "Location",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Akola District (Varhad Hub)",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                            )
                        }
                    }

                    // Quick Wallet summary Pill
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier
                            .clickable { viewModel.setCustomerTab("WALLET") }
                            .testTag("wallet_pill_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccountBalanceWallet,
                                contentDescription = "Wallet",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "₹${walletProfile?.walletBalance?.let { String.format("%.2f", it) } ?: "0.00"}",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }

        // --- SUB TABS CONTAINER / MAIN PANEL VIEW ---
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            when (activeTab) {
                "HOME" -> CustomerHomeView(viewModel)
                "DIRECTORY" -> LocalDirectoryView(viewModel)
                "FOOD" -> FoodDeliveryView(viewModel)
                "QUICK" -> QuickGroceryView(viewModel)
                "FARMER" -> FarmerMarketView(viewModel)
                "SERVICES" -> ServicesBookingView(viewModel)
                "JOBS" -> JobPortalView(viewModel)
                "EDUCATION" -> EducationView(viewModel)
                "COMMUNITY" -> CommunityView(viewModel)
                "WALLET" -> WalletAndSplitsView(viewModel)
                "CHAT" -> AiAssistantChatView(viewModel)
            }
        }

        // --- BOTTOM HORIZONTAL SCROLLABLE SUB-TABS SELECTOR ---
        ScrollableTabRow(viewModel)
    }
}

@Composable
fun ScrollableTabRow(viewModel: VdbViewModel) {
    val activeTab by viewModel.currentCustomerTab.collectAsState()
    val tabs = listOf(
        Triple("HOME", "Home", Icons.Default.Home),
        Triple("DIRECTORY", "Directory", Icons.Default.Search),
        Triple("FOOD", "VDB Food", Icons.Default.Restaurant),
        Triple("QUICK", "VDB Quick", Icons.Default.DeliveryDining),
        Triple("FARMER", "Agriculture", Icons.Default.Agriculture),
        Triple("SERVICES", "Services", Icons.Default.Build),
        Triple("JOBS", "VDB Jobs", Icons.Default.Work),
        Triple("EDUCATION", "Academy", Icons.Default.School),
        Triple("COMMUNITY", "Community", Icons.Default.Forum),
        Triple("WALLET", "Wallet logs", Icons.Default.AccountBalanceWallet),
        Triple("CHAT", "VDB AI", Icons.Default.SmartToy)
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .background(MaterialTheme.colorScheme.surface)
            .padding(vertical = 8.dp)
            .windowInsetsPadding(WindowInsets.navigationBars),
        horizontalArrangement = Arrangement.Start
    ) {
        tabs.forEach { (route, label, icon) ->
            val isSelected = activeTab == route
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .padding(horizontal = 10.dp)
                    .clickable { viewModel.setCustomerTab(route) }
                    .background(
                        color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
                        shape = RoundedCornerShape(12.dp)
                    )
                    .padding(horizontal = 14.dp, vertical = 6.dp)
                    .minimumInteractiveComponentSize()
                    .testTag("tab_$route")
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(22.dp)
                )
                Text(
                    text = label,
                    fontSize = 11.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

// ============================================
// 1. HOME TAB VIEW
// ============================================
@Composable
fun CustomerHomeView(viewModel: VdbViewModel) {
    val searchVal by viewModel.searchQuery.collectAsState()
    val cartItems by viewModel.cart.collectAsState()
    val totalCost by viewModel.cartTotal.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Vidarbha's Central Marketplace",
                        color = Color.White,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "Connecting Farmers, Local Shops, and Delivery Partners securely.",
                        color = Color.White.copy(alpha = 0.85f),
                        fontSize = 13.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = { viewModel.setCustomerTab("CHAT") },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.SmartToy, contentDescription = "AI")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Ask VDB Assistant", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Quick Category grid-style shortcuts
        item {
            Text(
                text = "Services and Verticals",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(8.dp))

            val categories = listOf(
                Quad("DIRECTORY", "Business Directory", Icons.Default.Search, Color(0xFFFF9933)),
                Quad("FOOD", "Restaurant Food", Icons.Default.Restaurant, Color(0xFFE65C00)),
                Quad("QUICK", "15-Min Quick Grocery", Icons.Default.FlashOn, Color(0xFFFF2A00)),
                Quad("FARMER", "Agriculture Mandi", Icons.Default.Agriculture, Color(0xFF2E7D32)),
                Quad("SERVICES", "Home Booking", Icons.Default.Build, Color(0xFF1565C0)),
                Quad("JOBS", "Local Job Board", Icons.Default.Work, Color(0xFF6A1B9A))
            )

            // Dynamic grid using Row wrap
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                for (i in 0 until categories.size step 2) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        for (j in i until minOf(i + 2, categories.size)) {
                            val cat = categories[j]
                            Card(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { viewModel.setCustomerTab(cat.route) }
                                    .minimumInteractiveComponentSize(),
                                shape = RoundedCornerShape(12.dp),
                                elevation = CardDefaults.cardElevation(1.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(cat.color.copy(alpha = 0.15f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = cat.icon,
                                            contentDescription = cat.title,
                                            tint = cat.color,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = cat.title,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Active Cart Drawer preview if items exist
        if (cartItems.isNotEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.tertiary),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.ShoppingCart,
                                    contentDescription = "Cart",
                                    tint = MaterialTheme.colorScheme.tertiary
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Your Cart (${cartItems.values.sum()} items)",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onTertiaryContainer
                                )
                            }
                            Text(
                                text = "₹${String.format("%.2f", totalCost)}",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.onTertiaryContainer
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Render each product in cart
                        cartItems.forEach { (prod, qty) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "$qty × ${prod.title}",
                                    fontSize = 13.sp,
                                    modifier = Modifier.weight(1f)
                                )
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(
                                        onClick = { viewModel.removeFromCart(prod) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.RemoveCircleOutline,
                                            contentDescription = "Remove",
                                            tint = Color.Red,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    IconButton(
                                        onClick = { viewModel.addToCart(prod) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.AddCircleOutline,
                                            contentDescription = "Add",
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                            }
                        }

                        Divider(modifier = Modifier.padding(vertical = 8.dp))

                        // Checkout split logs panel
                        Button(
                            onClick = { viewModel.checkoutCart() },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("checkout_button")
                        ) {
                            Text("Checkout & Split Payout (Wallet)", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Promote VDB Digital Cards
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.ContactPhone,
                        contentDescription = "Visiting card",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(40.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Register Your Own Shop!",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "Generate and share instant Digital Visiting Cards with QR code setup standard in Vidarbha.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                        )
                    }
                }
            }
        }
    }
}

// Helper tuple for categorizer map
data class Quad<A, B, C, D>(val route: A, val title: B, val icon: C, val color: D)

// ============================================
// 2. DIRECTORY & LOCAL SEARCH VIEW
// ============================================
@Composable
fun LocalDirectoryView(viewModel: VdbViewModel) {
    val query by viewModel.searchQuery.collectAsState()
    val allBusinesses by viewModel.businesses.collectAsState()

    val filteredList = allBusinesses.filter {
        it.name.contains(query, ignoreCase = true) ||
        it.category.contains(query, ignoreCase = true) ||
        it.taluka.contains(query, ignoreCase = true)
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        OutlinedTextField(
            value = query,
            onValueChange = { viewModel.updateSearchQuery(it) },
            label = { Text("Search local businesses (e.g. food, dairy)") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                        Icon(Icons.Default.Clear, contentDescription = "Clear")
                    }
                }
            },
            modifier = Modifier.fillMaxWidth().testTag("directory_search_input")
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Verified Akola & Vidarbha Business Units (${filteredList.size})",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(8.dp))

        if (filteredList.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize().weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text("No businesses match your search. Try 'Agro' or 'Dairy'.", textAlign = TextAlign.Center)
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredList) { b ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = b.name,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    if (b.kycStatus == "VERIFIED") {
                                        Icon(
                                            imageVector = Icons.Default.Verified,
                                            contentDescription = "Verified",
                                            tint = Color(0xFF2E7D32),
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = b.category,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "📍 ${b.taluka} Taluka • Tel: ${b.contactNo}",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            // Digital Visiting Card section
                            Spacer(modifier = Modifier.height(8.dp))
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.CardMembership, contentDescription = "Visiting Card", modifier = Modifier.size(20.dp), tint = MaterialTheme.colorScheme.primary)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "VDB Digital Card Active • Click to Dial",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Icon(Icons.Default.Phone, contentDescription = "Dial", modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ============================================
// 3. FOOD DELIVERY VIEW
// ============================================
@Composable
fun FoodDeliveryView(viewModel: VdbViewModel) {
    val allProducts by viewModel.products.collectAsState()
    val foodProducts = allProducts.filter { it.category == "FOOD" }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("VDB Food Delivery", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text("Warm, authentic meals prepared locally inside Akola and delivered via VDB Partners.", fontSize = 12.sp, modifier = Modifier.padding(bottom = 12.dp))

        if (foodProducts.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No food vendors active. Seeding...")
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(foodProducts) { item ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            // Food icon placeholder
                            Box(
                                modifier = Modifier
                                    .size(50.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFFE65C00).copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Restaurant, contentDescription = "Food", tint = Color(0xFFE65C00))
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(item.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(item.description, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("₹${item.price}", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("₹${String.format("%.1f", item.originalPrice)}", textDecoration = androidx.compose.ui.text.style.TextDecoration.LineThrough, fontSize = 11.sp, color = Color.Gray)
                                }
                            }

                            Button(
                                onClick = { viewModel.addToCart(item) },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                modifier = Modifier.testTag("add_food_${item.id}")
                            ) {
                                Text("Add", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ============================================
// 4. QUICK HYPERLOCAL GROCERY VIEW
// ============================================
@Composable
fun QuickGroceryView(viewModel: VdbViewModel) {
    val allProducts by viewModel.products.collectAsState()
    val quickProducts = allProducts.filter { it.category == "GROCERY" }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.FlashOn, contentDescription = "Fast", tint = Color.Red)
            Spacer(modifier = Modifier.width(6.dp))
            Text("VDB Quick - 10-30 Mins Delivery", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        }
        Text("Daily essentials like milk, organic ghee, spices - routed locally.", fontSize = 12.sp, modifier = Modifier.padding(bottom = 12.dp))

        if (quickProducts.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No grocery items found.")
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(quickProducts) { item ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(50.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF2E7D32).copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.ShoppingBag, contentDescription = "Grocery", tint = Color(0xFF2E7D32))
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(item.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(item.description, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("₹${item.price}", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
                            }

                            Button(
                                onClick = { viewModel.addToCart(item) },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                modifier = Modifier.testTag("add_grocery_${item.id}")
                            ) {
                                Text("Add", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ============================================
// 5. FARMER MARKET VIEW
// ============================================
@Composable
fun FarmerMarketView(viewModel: VdbViewModel) {
    val crops by viewModel.cropRates.collectAsState()
    val allProducts by viewModel.products.collectAsState()
    val agriProducts = allProducts.filter { it.category == "CROP" }
    val selectedFilter by viewModel.mandiFilter.collectAsState()

    val filteredCrops = if (selectedFilter == "ALL") crops else crops.filter { it.mandiName.contains(selectedFilter, ignoreCase = true) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text("VDB Farmer Market & Mandi Buzz", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
        Text("Live crop pricing (Akola and Amravati) and direct warehouse seeding buying.", fontSize = 12.sp)

        Spacer(modifier = Modifier.height(12.dp))

        // Mandi Filter Chips
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("ALL", "Akola", "Amravati", "Washim", "Yavatmal").forEach { filter ->
                FilterChip(
                    selected = selectedFilter == filter,
                    onClick = { viewModel.setMandiFilter(filter) },
                    label = { Text(filter) }
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Live Mandi Ticker Card
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.TrendingUp, contentDescription = "Trend", tint = Color(0xFF2E7D32))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("LIVE Mandi Rates (₹ per Quintal)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }

                Spacer(modifier = Modifier.height(10.dp))

                filteredCrops.forEach { crop ->
                    val isUp = crop.currentRatePerQuintal >= crop.previousRatePerQuintal
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(crop.cropNameEn, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text("Mandi: ${crop.mandiName}", fontSize = 10.sp, color = Color.Gray)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("₹${crop.currentRatePerQuintal}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = if (isUp) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                                contentDescription = "Direction",
                                tint = if (isUp) Color(0xFF2E7D32) else Color.Red,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Farmers Agri Store
        Text("Agri-Protection Inputs & Seeds", fontSize = 15.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))

        agriProducts.forEach { item ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(item.title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(item.description, fontSize = 11.sp, color = Color.Gray)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("₹${item.price} per Unit", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                    Button(
                        onClick = { viewModel.addToCart(item) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
                    ) {
                        Text("Buy", fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

// ============================================
// 6. SERVICES BOOKING VIEW
// ============================================
@Composable
fun ServicesBookingView(viewModel: VdbViewModel) {
    val allProducts by viewModel.products.collectAsState()
    val services = allProducts.filter { it.category == "SERVICE" }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("VDB Services Booking", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text("Hire local technicians, plumbers, and high school tutors instantly.", fontSize = 12.sp, modifier = Modifier.padding(bottom = 12.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(services) { svc ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF1565C0).copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Handyman, contentDescription = "Tool", tint = Color(0xFF1565C0))
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(svc.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(svc.description, fontSize = 11.sp, color = Color.Gray)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Rate: ₹${svc.price}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        }

                        Button(
                            onClick = { viewModel.addToCart(svc) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1565C0)),
                            modifier = Modifier.testTag("book_service_${svc.id}")
                        ) {
                            Text("Book")
                        }
                    }
                }
            }
        }
    }
}

// ============================================
// 7. JOB PORTAL VIEW
// ============================================
@Composable
fun JobPortalView(viewModel: VdbViewModel) {
    val jobs by viewModel.jobListings.collectAsState()
    var resumeName by remember { mutableStateOf("") }
    var appliedJobId by remember { mutableStateOf<String?>(null) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Local Job Board & Hiring Hub", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text("Empowering Vidarbha youth with verified hyperlocal driver, farm & logistics roles.", fontSize = 12.sp)

        Spacer(modifier = Modifier.height(12.dp))

        // Resume upload simulation
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text("Simulate Resume Upload", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = resumeName,
                        onValueChange = { resumeName = it },
                        placeholder = { Text("e.g. Ramesh_Gawande_CV.pdf") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { if (resumeName.isNotEmpty()) resumeName = "$resumeName (UPLOADED! ✔)" },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                    ) {
                        Text("Attach")
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(jobs) { job ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(job.title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                                Text(
                                    text = job.jobType,
                                    fontSize = 10.sp,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Text("📍 Local: ${job.location} • ${job.businessName}", fontSize = 11.sp, color = Color.Gray)
                        Text("Compensation: ${job.salaryText}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(vertical = 4.dp))
                        Text(job.description, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Applicants in queue: ${job.applicantsCount}", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            
                            val isAlreadyApplied = appliedJobId == job.id
                            Button(
                                onClick = {
                                    viewModel.applyForJob(job.id)
                                    appliedJobId = job.id
                                },
                                enabled = !isAlreadyApplied,
                                modifier = Modifier.testTag("apply_job_${job.id}")
                            ) {
                                Text(if (isAlreadyApplied) "Applied ✔" else "Instant Apply")
                            }
                        }
                    }
                }
            }
        }
    }
}

// ============================================
// 8. EDUCATION & TRAINING VIEW
// ============================================
@Composable
fun EducationView(viewModel: VdbViewModel) {
    val classes by viewModel.courses.collectAsState()
    var completedLessonsMap by remember { mutableStateOf(mutableMapOf<String, Int>()) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("VDB Academy - Entrepreneurship & Skills", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text("Empowering small merchants and growers to manage financial audit and build digital branding.", fontSize = 12.sp)

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(classes) { cl ->
                val currentProgress = completedLessonsMap[cl.id] ?: 0
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(cl.titleEn, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(cl.titleMr, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                            }
                            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF2E7D32).copy(alpha = 0.12f))) {
                                Text(
                                    text = "FREE",
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF2E7D32),
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Text("Trainer: ${cl.trainer} • Duration: ${cl.durationMin} mins", fontSize = 11.sp, color = Color.Gray, modifier = Modifier.padding(vertical = 4.dp))
                        Text(cl.description, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            LinearProgressIndicator(
                                progress = if (cl.lessonsCount > 0) currentProgress.toFloat() / cl.lessonsCount else 0f,
                                modifier = Modifier.weight(1f).height(6.dp).clip(RoundedCornerShape(3.dp))
                            )
                            Spacer(modifier = Modifier.width(16.dp))
                            Text("$currentProgress/${cl.lessonsCount} Lessons", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Button(
                            onClick = {
                                val next = (currentProgress + 1).coerceAtMost(cl.lessonsCount)
                                val updated = completedLessonsMap.toMutableMap()
                                updated[cl.id] = next
                                completedLessonsMap = updated
                            },
                            modifier = Modifier.align(Alignment.End).testTag("play_lesson_${cl.id}")
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = "Play")
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Next Lesson")
                        }
                    }
                }
            }
        }
    }
}

// ============================================
// 9. COMMUNITY BULLETIN & NEWS VIEW
// ============================================
@Composable
fun CommunityView(viewModel: VdbViewModel) {
    val posts by viewModel.communityPosts.collectAsState()
    var wordInput by remember { mutableStateOf("") }
    var areaInput by remember { mutableStateOf("Akola Central") }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Local VDB Community Board", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text("Share crop updates, cooperative deals, regional rain details or MSME meetups across Wardha & Akola.", fontSize = 12.sp)

        Spacer(modifier = Modifier.height(12.dp))

        // Create a local post
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text("Write Local Post", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = wordInput,
                    onValueChange = { wordInput = it },
                    placeholder = { Text("Share cotton updates, local tractor rentals etc.") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = areaInput,
                        onValueChange = { areaInput = it },
                        label = { Text("District/Taluka location") },
                        modifier = Modifier.width(160.dp),
                        singleLine = true
                    )
                    Button(
                        onClick = {
                            if (wordInput.isNotEmpty()) {
                                viewModel.postLocalCommunityUpdate(wordInput, areaInput)
                                wordInput = ""
                            }
                        },
                        modifier = Modifier.testTag("post_community_button")
                    ) {
                        Text("Post")
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(posts) { post ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(post.authorName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("Role: ${post.authorRole} • 📍 ${post.areaName}", fontSize = 10.sp, color = Color.Gray)
                            }
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(MaterialTheme.colorScheme.secondaryContainer)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text("Citizens", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(post.content, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Start,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = { viewModel.upvotePost(post.id) },
                                modifier = Modifier.size(24.dp).testTag("upvote_${post.id}")
                            ) {
                                Icon(Icons.Default.ThumbUp, contentDescription = "Like", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                            }
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("${post.likesCount} Upvotes", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// ============================================
// 10. WALLET, MUTUAL SETTLEMENT & REVENUE SPLITSTab
// ============================================
@Composable
fun WalletAndSplitsView(viewModel: VdbViewModel) {
    val walletProfile by viewModel.customerProfile.collectAsState()
    val vendorProfile by viewModel.vendorProfile.collectAsState()
    val deliveryProfile by viewModel.deliveryProfile.collectAsState()
    val franchiseProfile by viewModel.franchiseProfile.collectAsState()
    val adminProfile by viewModel.adminProfile.collectAsState()

    val orders by viewModel.allOrders.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("VDB Unified Wallet & Split Settlement", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text("Real-time distributed settlement engine demonstrating split transactions.", fontSize = 12.sp)

        // Customer's Personal Wallet
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Your Wallet Balance (Customer)", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                Text(
                    text = "₹${walletProfile?.walletBalance?.let { String.format("%.2f", it) } ?: "0.00"}",
                    color = Color.White,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.ExtraBold
                )
                Text("VDB Reward Points earned: ${walletProfile?.loyaltyPoints ?: 0} PTS", color = Color.White.copy(alpha = 0.9f), fontSize = 11.sp)

                Spacer(modifier = Modifier.height(10.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { viewModel.addWalletFunds(500.0) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)
                    ) {
                        Text("+₹500")
                    }
                    Button(
                        onClick = { viewModel.addWalletFunds(1000.0) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)
                    ) {
                        Text("+₹1000")
                    }
                }
            }
        }

        // Live Ecosystem Balances (Simulation proving real split accounting)
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            modifier = Modifier.fillMaxWidth().testTag("wallet_logs_card")
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text("Live Ecosystem Balance Sync (Multi-Party Audit)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(8.dp))

                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text("Vendor Wallet (Suresh - Bhojnalaya):", fontSize = 12.sp)
                    Text("₹${vendorProfile?.walletBalance?.let { String.format("%.2f", it) } ?: "0.0"}", fontWeight = FontWeight.Bold)
                }
                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text("Logistics Rider Wallet (Ganesh):", fontSize = 12.sp)
                    Text("₹${deliveryProfile?.walletBalance?.let { String.format("%.2f", it) } ?: "0.0"}", fontWeight = FontWeight.Bold)
                }
                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text("Akola Franchise Coord. Wallet (Anandrao):", fontSize = 12.sp)
                    Text("₹${franchiseProfile?.walletBalance?.let { String.format("%.2f", it) } ?: "0.0"}", fontWeight = FontWeight.Bold)
                }
                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text("VDB Platform Fee Admin Treasury:", fontSize = 12.sp)
                    Text("₹${adminProfile?.walletBalance?.let { String.format("%.2f", it) } ?: "0.0"}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }
            }
        }

        Divider()

        // Transaction logs with detailed split breakups
        Text("Your Order Settlement History", fontWeight = FontWeight.Bold, fontSize = 14.sp)

        if (orders.filter { it.customerPhone == viewModel.activeCustomerPhone }.isEmpty()) {
            Text("No transactions found yet. Place food/grocery orders to trigger payout split checks.", fontSize = 12.sp, color = Color.Gray, textAlign = TextAlign.Center, modifier = Modifier.padding(8.dp))
        } else {
            orders.filter { it.customerPhone == viewModel.activeCustomerPhone }.forEach { order ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(order.id, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                            Text("₹${String.format("%.2f", order.totalAmount)}", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                        }

                        Text("Items: ${order.itemsSummary}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("Merchant: ${order.businessName} • Status: ${order.status}", fontSize = 11.sp, color = Color.Gray)

                        Spacer(modifier = Modifier.height(4.dp))
                        Row {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color(0xFF2E7D32).copy(alpha = 0.12f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text("Vendor: ₹${String.format("%.2f", order.vendorShare)}", fontSize = 10.sp, color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color(0xFF1565C0).copy(alpha = 0.12f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text("Rider: ₹${String.format("%.2f", order.deliveryShare)}", fontSize = 10.sp, color = Color(0xFF1565C0), fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color(0xFFE65C00).copy(alpha = 0.12f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text("Franchise: ₹${String.format("%.2f", order.franchiseShare)}", fontSize = 10.sp, color = Color(0xFFE65C00), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ============================================
// 11. DYNAMIC AI ASSISTANT CHAT VIEW
// ============================================
@Composable
fun AiAssistantChatView(viewModel: VdbViewModel) {
    val messages by viewModel.chatMessages.collectAsState()
    val isLoading by viewModel.isAiLoading.collectAsState()
    var typedText by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("VDB AI Smart Assistant (Gemini Flash)", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text("Get real-time crop yields, voice ordering simulations, and digital marketing insights.", fontSize = 11.sp)

        Spacer(modifier = Modifier.height(8.dp))

        // Chat feed container
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                .padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(messages) { msg ->
                val isUser = msg.first == "User"
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart
                ) {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isUser) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.widthIn(max = 280.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = if (isUser) "You" else "VDB Guru (AI)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                color = if (isUser) Color.White.copy(alpha = 0.8f) else MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = msg.second,
                                fontSize = 12.sp,
                                color = if (isUser) Color.White else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            if (isLoading) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(8.dp),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Gemini thinking...", fontSize = 12.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Input row
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = typedText,
                onValueChange = { typedText = it },
                placeholder = { Text("Ask about crops, shev bhaji thali, or bills...") },
                modifier = Modifier
                    .weight(1f)
                    .testTag("ai_chat_input"),
                singleLine = true
            )
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(
                onClick = {
                    if (typedText.isNotEmpty()) {
                        viewModel.sendUserMessage(typedText)
                        typedText = ""
                    }
                },
                modifier = Modifier
                    .size(48.dp)
                    .background(MaterialTheme.colorScheme.primary, CircleShape)
                    .testTag("send_ai_button")
            ) {
                Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.White)
            }
        }
    }
}
