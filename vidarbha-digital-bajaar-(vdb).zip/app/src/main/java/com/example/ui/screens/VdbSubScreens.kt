package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.viewmodel.VdbViewModel

// ====================================================================
// VENDOR DASHBOARD
// ====================================================================
@Composable
fun VendorDashboard(viewModel: VdbViewModel) {
    val orders by viewModel.allOrders.collectAsState()
    val vendorProfile by viewModel.vendorProfile.collectAsState()

    var productTitle by remember { mutableStateOf("") }
    var productDesc by remember { mutableStateOf("") }
    var productPrice by remember { mutableStateOf("") }
    var productCat by remember { mutableStateOf("FOOD") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("VDB Vendor Ecosystem Panel", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text("Manager: Suresh Padhye (Saraswati Bhojnalaya)", fontSize = 11.sp, color = Color.Gray)
            }
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer)
                    .padding(8.dp)
            ) {
                Text(
                    text = "Balance: ₹${vendorProfile?.walletBalance?.let { String.format("%.2f", it) } ?: "0.0"}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }

        // Custom Compose Canvas Trend Graph - Sales Trend over last 5 days
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text("Weekly Sales Analytics Dashboard (Varhadi Hubs)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text("Continuous metrics tracking in Akola region.", fontSize = 11.sp, color = Color.Gray)
                
                Spacer(modifier = Modifier.height(16.dp))

                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(80.dp)
                ) {
                    val width = size.width
                    val height = size.height
                    
                    // Sales values: 2400, 3200, 4100, 3800, 5200
                    val points = listOf(0.2f, 0.4f, 0.65f, 0.58f, 0.9f)
                    val stepX = width / (points.size - 1)
                    
                    // Draw grid lines
                    for (i in 1..3) {
                        val gridY = height * (i / 4f)
                        drawLine(
                            color = Color.LightGray.copy(alpha = 0.5f),
                            start = androidx.compose.ui.geometry.Offset(0f, gridY),
                            end = androidx.compose.ui.geometry.Offset(width, gridY),
                            strokeWidth = 1.dp.toPx()
                        )
                    }

                    // Draw Line Plot
                    for (i in 0 until points.size - 1) {
                        val startX = i * stepX
                        val startY = height - (points[i] * height)
                        val endX = (i + 1) * stepX
                        val endY = height - (points[i + 1] * height)

                        drawLine(
                            color = Color(0xFFFF9933), // Marigold
                            start = androidx.compose.ui.geometry.Offset(startX, startY),
                            end = androidx.compose.ui.geometry.Offset(endX, endY),
                            strokeWidth = 3.dp.toPx()
                        )

                        drawCircle(
                            color = Color(0xFFE65C00),
                            radius = 4.dp.toPx(),
                            center = androidx.compose.ui.geometry.Offset(startX, startY)
                        )
                    }
                    drawCircle(
                        color = Color(0xFFE65C00),
                        radius = 4.dp.toPx(),
                        center = androidx.compose.ui.geometry.Offset(width, height - (points.last() * height))
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Mon", fontSize = 10.sp, color = Color.Gray)
                    Text("Tue", fontSize = 10.sp, color = Color.Gray)
                    Text("Wed", fontSize = 10.sp, color = Color.Gray)
                    Text("Thu", fontSize = 10.sp, color = Color.Gray)
                    Text("Fri (Today)", fontSize = 10.sp, color = Color.Gray)
                }
            }
        }

        // Insert new product
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Add New Product Catalog Entry", fontWeight = FontWeight.Bold, fontSize = 13.sp)

                OutlinedTextField(
                    value = productTitle,
                    onValueChange = { productTitle = it },
                    label = { Text("Product name (e.g. Basundi, Kesar Kulfi)") },
                    modifier = Modifier.fillMaxWidth().testTag("product_title_input"),
                    singleLine = true
                )

                OutlinedTextField(
                    value = productDesc,
                    onValueChange = { productDesc = it },
                    label = { Text("Product description & notes") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = productPrice,
                        onValueChange = { productPrice = it },
                        label = { Text("Price (₹)") },
                        modifier = Modifier.weight(1f).testTag("product_price_input"),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = productCat,
                        onValueChange = { productCat = it },
                        label = { Text("Category (FOOD/GROCERY)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                Button(
                    onClick = {
                        val pr = productPrice.toDoubleOrNull() ?: 0.0
                        if (productTitle.isNotEmpty() && pr > 0) {
                            viewModel.addVendorProduct(productTitle, productDesc, pr, productCat)
                            productTitle = ""
                            productDesc = ""
                            productPrice = ""
                        }
                    },
                    modifier = Modifier.align(Alignment.End).testTag("vendor_add_product_button")
                ) {
                    Text("Register Product")
                }
            }
        }

        // Active Orders panel for vendor dispatch
        Text("Your Active Customer Orders Queue", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        val activeIncoming = orders.filter { it.status == "PENDING" || it.status == "CONFIRMED" || it.status == "PREPARING" }

        if (activeIncoming.isEmpty()) {
            Text("No incoming orders found yet. Switch role to customer to place mock orders.", fontSize = 12.sp, color = Color.Gray, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        } else {
            activeIncoming.forEach { ord ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(ord.id, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("₹${String.format("%.2f", ord.totalAmount)}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        }
                        Text("Items: ${ord.itemsSummary}", fontSize = 12.sp)
                        Text("Customer: ${ord.customerName} (${ord.customerPhone})", fontSize = 11.sp, color = Color.Gray)
                        Text("Current status: ${ord.status}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFF9933))

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { viewModel.updateOrderStatusAsVendor(ord.id, "PREPARING") },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                modifier = Modifier.testTag("vendor_prepare_${ord.id}")
                            ) {
                                Text("Prepare Thali", fontSize = 11.sp)
                            }
                            Button(
                                onClick = { viewModel.updateOrderStatusAsVendor(ord.id, "OUT_FOR_DELIVERY") },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text("Handover to VDB Rider", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ====================================================================
// DELIVERY PARTNER DASHBOARD
// ====================================================================
@Composable
fun DeliveryDashboard(viewModel: VdbViewModel) {
    val orders by viewModel.allOrders.collectAsState()
    val riderProfile by viewModel.deliveryProfile.collectAsState()

    var activeRouteSegment by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("VDB Rider Dispatcher Core", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text("Driver: Ganesh Shinde (Akola Hub Courier)", fontSize = 11.sp, color = Color.Gray)
            }
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF1565C0).copy(alpha = 0.12f))
                    .padding(8.dp)
            ) {
                Text(
                    text = "My Earnings: ₹${riderProfile?.walletBalance?.let { String.format("%.2f", it) } ?: "0.0"}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = Color(0xFF1565C0)
                )
            }
        }

        // GPS Routing Map Simulation widget
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text("VDB GIS Hyperlocal Maps Router", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(
                    text = if (activeRouteSegment != null) "Navigating active route segment: $activeRouteSegment" else "Select a delivery queue packet to project GPS route coordinates.",
                    fontSize = 11.sp,
                    color = Color.Gray
                )

                Spacer(modifier = Modifier.height(12.dp))

                // GPS route simulator drawing canvas
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .background(Color(0xFFE8F5E9), RoundedCornerShape(8.dp))
                ) {
                    val width = size.width
                    val height = size.height

                    // Draw roads/grids as background
                    drawLine(Color.White, androidx.compose.ui.geometry.Offset(0f, height/2), androidx.compose.ui.geometry.Offset(width, height/2), strokeWidth = 10f)
                    drawLine(Color.White, androidx.compose.ui.geometry.Offset(width/3, 0f), androidx.compose.ui.geometry.Offset(width/3, height), strokeWidth = 8f)
                    drawLine(Color.White, androidx.compose.ui.geometry.Offset(2*width/3, 0f), androidx.compose.ui.geometry.Offset(2*width/3, height), strokeWidth = 8f)

                    // Draw Merchant location (Saraswati Bhojnalaya)
                    drawCircle(
                        Color(0xFFFF9933),
                        radius = 12f,
                        center = androidx.compose.ui.geometry.Offset(width/3, height/2)
                    )

                    // Draw Customer drop coordinate
                    drawCircle(
                        Color(0xFF1565C0),
                        radius = 12f,
                        center = androidx.compose.ui.geometry.Offset(2*width/3, height/3)
                    )

                    // Route path line in solid blue if route is active
                    if (activeRouteSegment != null) {
                        val path = androidx.compose.ui.graphics.Path().apply {
                            moveTo(width/3, height/2)
                            lineTo(2*width/3, height/2)
                            lineTo(2*width/3, height/3)
                        }
                        drawPath(
                            path = path,
                            color = Color(0xFF1976D2),
                            style = Stroke(width = 6f)
                        )
                    }

                    // Radar pulse circle on position
                    drawCircle(
                        Color.Red,
                        radius = 6f,
                        center = androidx.compose.ui.geometry.Offset(width/3 + 30f, height/2)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("📍 Merchant (Bhojnalaya)", fontSize = 9.sp, color = Color(0xFFE65C00), fontWeight = FontWeight.Bold)
                    Text("🏁 Customer (Ramesh Gawande)", fontSize = 9.sp, color = Color(0xFF1565C0), fontWeight = FontWeight.Bold)
                }
            }
        }

        // Live Orders Queue
        Text("Your Active Delivery Backlog", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        val deliveryQueue = orders.filter { it.status == "PENDING" || it.status == "CONFIRMED" || it.status == "PREPARING" || it.status == "OUT_FOR_DELIVERY" }

        if (deliveryQueue.isEmpty()) {
            Text("No packages ready in Akola zone. Create an order from customer panel.", fontSize = 12.sp, color = Color.Gray, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        } else {
            deliveryQueue.forEach { ord ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text("ID: ${ord.id}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("Payout: ₹${String.format("%.2f", ord.deliveryShare)}", fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
                        }
                        Text("Address: Akola Central Housing (Varhad)", fontSize = 11.sp)
                        Text("Merchant: ${ord.businessName} • Status: ${ord.status}", fontSize = 11.sp, color = Color.Gray)

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = {
                                    viewModel.acceptOrderAsDeliveryPartner(ord.id)
                                    activeRouteSegment = "${ord.businessName} ➔ Customer Rajesh"
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                modifier = Modifier.testTag("rider_accept_${ord.id}")
                            ) {
                                Text("Map Route", fontSize = 11.sp)
                            }
                            Button(
                                onClick = {
                                    viewModel.completeDelivery(ord.id)
                                    activeRouteSegment = null
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                enabled = ord.status == "OUT_FOR_DELIVERY"
                            ) {
                                Text("Delivered ✔", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ====================================================================
// FRANCHISE PARTNER DASHBOARD
// ====================================================================
@Composable
fun FranchiseDashboard(viewModel: VdbViewModel) {
    val franchiseProfile by viewModel.franchiseProfile.collectAsState()
    val orders by viewModel.allOrders.collectAsState()

    var partnerLeadName by remember { mutableStateOf("") }
    var partnerLeadCat by remember { mutableStateOf("FARM_PRODUCE") }
    var partnerLeadTaluka by remember { mutableStateOf("Akola") }
    var partnerLeadPhone by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Franchise Territory Coordinator", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text("Manager: Anandrao Patil (Akola Division)", fontSize = 11.sp, color = Color.Gray)
            }
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFFE65C00).copy(alpha = 0.12f))
                    .padding(8.dp)
            ) {
                Text(
                    text = "Commissions Earned: ₹${franchiseProfile?.walletBalance?.let { String.format("%.2f", it) } ?: "0.0"}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = Color(0xFFE65C00)
                )
            }
        }

        // Territory details
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text("Akola Territory Coverage", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text("You earn a localized 2% split on all e-commerce, meal, and agricultural transactions inside your borders.", fontSize = 11.sp, color = Color.Gray)

                Spacer(modifier = Modifier.height(12.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Card(modifier = Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                        Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Verified Vendors", fontSize = 10.sp, color = Color.Gray)
                            Text("5 Units", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                    }
                    Card(modifier = Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                        Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Couriers Onboarded", fontSize = 10.sp, color = Color.Gray)
                            Text("18 Riders", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                    }
                    Card(modifier = Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                        Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Territory Leads", fontSize = 10.sp, color = Color.Gray)
                            Text("120 Leads", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                    }
                }
            }
        }

        // Lead Acquisition Form
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Acquire & Register New Business Lead", fontWeight = FontWeight.Bold, fontSize = 13.sp)

                OutlinedTextField(
                    value = partnerLeadName,
                    onValueChange = { partnerLeadName = it },
                    label = { Text("Lead shop name (e.g. Shegaon Kachori Spl)") },
                    modifier = Modifier.fillMaxWidth().testTag("lead_name_input"),
                    singleLine = true
                )

                OutlinedTextField(
                    value = partnerLeadPhone,
                    onValueChange = { partnerLeadPhone = it },
                    label = { Text("Lead registration phone number") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = partnerLeadCat,
                        onValueChange = { partnerLeadCat = it },
                        label = { Text("Type (RESTAURANT/GROCERY)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = partnerLeadTaluka,
                        onValueChange = { partnerLeadTaluka = it },
                        label = { Text("Taluka name") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                Button(
                    onClick = {
                        if (partnerLeadName.isNotEmpty() && partnerLeadPhone.isNotEmpty()) {
                            viewModel.registerNewBusiness(partnerLeadName, partnerLeadCat, partnerLeadTaluka, partnerLeadPhone)
                            partnerLeadName = ""
                            partnerLeadPhone = ""
                        }
                    },
                    modifier = Modifier.align(Alignment.End).testTag("franchise_save_lead_button")
                ) {
                    Text("Save Lead & Request Admin KYC Approval")
                }
            }
        }

        // Live Commission Settlements logs
        Text("Your Territory Commission logs (2% Share)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        val customerTransactions = orders.filter { it.totalAmount > 0 }

        if (customerTransactions.isEmpty()) {
            Text("No transactions processed inside Akola yet.", fontSize = 12.sp, color = Color.Gray, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        } else {
            customerTransactions.forEach { tr ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text("Tx: ${tr.id}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text("Commission: +₹${String.format("%.2f", tr.franchiseShare)}", fontWeight = FontWeight.Bold, color = Color(0xFFE65C00))
                        }
                        Text("Business Unit: ${tr.businessName} • Sale Amt: ₹${tr.totalAmount}", fontSize = 11.sp, color = Color.Gray)
                    }
                }
            }
        }
    }
}

// ====================================================================
// SUPER ADMIN DASHBOARD
// ====================================================================
@Composable
fun SuperAdminDashboard(viewModel: VdbViewModel) {
    val businesses by viewModel.businesses.collectAsState()
    val adminProfile by viewModel.adminProfile.collectAsState()
    val orders by viewModel.allOrders.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("VDB Super-Admin Moderator", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text("Role: Platform Security and Indian IT Act Compliance", fontSize = 11.sp, color = Color.Gray)
            }
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.Red.copy(alpha = 0.12f))
                    .padding(8.dp)
            ) {
                Text(
                    text = "VDB Fee: ₹${adminProfile?.walletBalance?.let { String.format("%.2f", it) } ?: "0.0"}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = Color.Red
                )
            }
        }

        // Platform Summary metrics
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text("VDB platform Diagnostics & Health", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(10.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Total Platform Transactions:", fontSize = 12.sp)
                    Text("${orders.size} Orders", fontWeight = FontWeight.Bold)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Platform volume processed:", fontSize = 12.sp)
                    Text("₹${String.format("%.2f", orders.sumOf { it.totalAmount })}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Total onboarded partner merchants:", fontSize = 12.sp)
                    Text("${businesses.size} Registered", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Verification queue (KYC)
        Text("Pending Merchant Registration Queue", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        val pendingKyc = businesses.filter { it.kycStatus == "PENDING" }

        if (pendingKyc.isEmpty()) {
            Text("No merchant registries pending review. Clear queue! ✔", fontSize = 12.sp, color = Color.Gray, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        } else {
            pendingKyc.forEach { shop ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text(shop.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(shop.category, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Text("Mandi Location: ${shop.taluka} Taluka • Tel: ${shop.contactNo}", fontSize = 11.sp, color = Color.Gray)

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { viewModel.verifyBusinessKyc(shop.id, true) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                modifier = Modifier.testTag("admin_verify_${shop.id}")
                            ) {
                                Text("Approve KYC & Verify", fontSize = 11.sp)
                            }
                            Button(
                                onClick = { viewModel.verifyBusinessKyc(shop.id, false) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp)
                            ) {
                                Text("Reject", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
