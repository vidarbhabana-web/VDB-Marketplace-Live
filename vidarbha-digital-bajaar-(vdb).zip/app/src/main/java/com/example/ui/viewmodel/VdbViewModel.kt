package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.data.local.VdbDatabase
import com.example.data.local.VdbDao
import com.example.data.model.*
import com.example.data.remote.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

class VdbViewModel(application: Application) : AndroidViewModel(application) {
    private val vdbDao: VdbDao = VdbDatabase.getDatabase(application).vdbDao()

    // --- NAVIGATION & TENANT STATES ---
    private val _currentRole = MutableStateFlow("CUSTOMER") // CUSTOMER, VENDOR, DELIVERY, FRANCHISE, ADMIN
    val currentRole: StateFlow<String> = _currentRole.asStateFlow()

    private val _currentCustomerTab = MutableStateFlow("HOME") // HOME, DIRECTORY, FOOD, QUICK, FARMER, SERVICES, JOBS, EDUCATION, COMMUNITY, WALLET, CHAT
    val currentCustomerTab: StateFlow<String> = _currentCustomerTab.asStateFlow()

    // Active User (Customer) Profile
    val activeCustomerPhone = "9876543210"
    val activeVendorPhone = "9988776655"
    val activeDeliveryPhone = "9112233445"
    val activeFranchisePhone = "9555666777"

    val customerProfile: StateFlow<UserProfile?> = vdbDao.getUserProfile(activeCustomerPhone)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val vendorProfile: StateFlow<UserProfile?> = vdbDao.getUserProfile(activeVendorPhone)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val deliveryProfile: StateFlow<UserProfile?> = vdbDao.getUserProfile(activeDeliveryPhone)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val franchiseProfile: StateFlow<UserProfile?> = vdbDao.getUserProfile(activeFranchisePhone)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val adminProfile: StateFlow<UserProfile?> = vdbDao.getUserProfile("9000000000")
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // --- REACTIVE LISTS FROM DATABASE ---
    val businesses: StateFlow<List<Business>> = vdbDao.getAllBusinesses()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val products: StateFlow<List<Product>> = vdbDao.getAllProducts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val cropRates: StateFlow<List<CropRate>> = vdbDao.getCropRates()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val jobListings: StateFlow<List<JobListing>> = vdbDao.getJobListings()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val courses: StateFlow<List<EducationalCourse>> = vdbDao.getCourses()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val communityPosts: StateFlow<List<CommunityPost>> = vdbDao.getCommunityFeed()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allOrders: StateFlow<List<OrderItem>> = vdbDao.getAllOrders()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- CLIENT STATE: CART ---
    private val _cart = MutableStateFlow<Map<Product, Int>>(emptyMap())
    val cart: StateFlow<Map<Product, Int>> = _cart.asStateFlow()

    val cartTotal: StateFlow<Double> = _cart.map { cartMap ->
        cartMap.entries.sumOf { it.key.price * it.value }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // --- SEARCH FILTERS ---
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _mandiFilter = MutableStateFlow("ALL") // ALL, Akola, Amravati, Washim
    val mandiFilter: StateFlow<String> = _mandiFilter.asStateFlow()

    // --- AI ASSISTANT CHAT ---
    private val _chatMessages = MutableStateFlow<List<Pair<String, String>>>(listOf(
        "AI" to "Namaskar! Welcome to Vidarbha Digital Bajaar. I am your VDB AI assistant. Ask me to:\n• Buy shev bhaji or milk\n• Suggest marketing tips\n• Check mandi cotton prices\n• Register a business"
    ))
    val chatMessages: StateFlow<List<Pair<String, String>>> = _chatMessages.asStateFlow()

    private val _isAiLoading = MutableStateFlow(false)
    val isAiLoading: StateFlow<Boolean> = _isAiLoading.asStateFlow()

    init {
        seedInitialDatabase()
    }

    // --- MUTATORS & BUSINESS ACTIONS ---

    fun setRole(role: String) {
        _currentRole.value = role
    }

    fun setCustomerTab(tab: String) {
        _currentCustomerTab.value = tab
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setMandiFilter(filter: String) {
        _mandiFilter.value = filter
    }

    fun addToCart(product: Product) {
        val current = _cart.value.toMutableMap()
        current[product] = (current[product] ?: 0) + 1
        _cart.value = current
    }

    fun removeFromCart(product: Product) {
        val current = _cart.value.toMutableMap()
        val count = current[product] ?: 0
        if (count <= 1) {
            current.remove(product)
        } else {
            current[product] = count - 1
        }
        _cart.value = current
    }

    fun clearCart() {
        _cart.value = emptyMap()
    }

    // Interactive checkout with Wallet balance deductions and multi-party payment split.
    fun checkoutCart(paymentMethod: String = "WALLET") {
        val cartItems = _cart.value
        if (cartItems.isEmpty()) return

        viewModelScope.launch(Dispatchers.IO) {
            val total = cartItems.entries.sumOf { it.key.price * it.value }
            val itemsDesc = cartItems.entries.joinToString(", ") { "${it.value}x ${it.key.title}" }
            
            // Pick the first item's business to group order
            val mainProduct = cartItems.keys.first()
            val bId = mainProduct.businessId
            val bName = mainProduct.businessName

            // Get profile
            val customer = vdbDao.getUserProfileSynchronous(activeCustomerPhone)
            if (customer == null) return@launch

            if (customer.walletBalance < total && paymentMethod == "WALLET") {
                withContext(Dispatchers.Main) {
                     _chatMessages.value = _chatMessages.value + ("AI" to "Checkout Failed: Insufficient wallet balance! Please add funds in your Wallet tab.")
                }
                return@launch
            }

            // Calculations
            val platformFee = total * 0.08
            val vendorPayout = total * 0.85
            val deliveryPayout = total * 0.05
            val franchiseCommission = total * 0.02

            // Create Order
            val order = OrderItem(
                id = "VDB-" + UUID.randomUUID().toString().take(6).uppercase(),
                customerPhone = activeCustomerPhone,
                customerName = customer.fullName,
                businessId = bId,
                businessName = bName,
                itemsSummary = itemsDesc,
                totalAmount = total,
                status = "PENDING",
                paymentMethod = paymentMethod,
                isSettled = true,
                platformFee = platformFee,
                vendorShare = vendorPayout,
                deliveryShare = deliveryPayout,
                franchiseShare = franchiseCommission
            )

            // Deduct customer wallet
            vdbDao.updateUserProfile(customer.copy(
                walletBalance = customer.walletBalance - total,
                loyaltyPoints = customer.loyaltyPoints + (total / 10).toInt()
            ))

            // Add value to vendor, delivery, franchise wallets in parallel
            vdbDao.getUserProfileSynchronous(activeVendorPhone)?.let { v ->
                vdbDao.updateUserProfile(v.copy(walletBalance = v.walletBalance + vendorPayout))
            }
            vdbDao.getUserProfileSynchronous(activeDeliveryPhone)?.let { d ->
                vdbDao.updateUserProfile(d.copy(walletBalance = d.walletBalance + deliveryPayout))
            }
            vdbDao.getUserProfileSynchronous(activeFranchisePhone)?.let { f ->
                vdbDao.updateUserProfile(f.copy(walletBalance = f.walletBalance + franchiseCommission))
            }
            vdbDao.getUserProfileSynchronous("9000000000")?.let { admin ->
                vdbDao.updateUserProfile(admin.copy(walletBalance = admin.walletBalance + platformFee))
            }

            // Save order to database
            vdbDao.insertOrder(order)

            withContext(Dispatchers.Main) {
                clearCart()
                _currentCustomerTab.value = "WALLET" // take them to checkout logs
                _chatMessages.value = _chatMessages.value + ("AI" to "Kudos! Order placed successfully at $bName for ₹$total. Split payout processed:\n✔ Vendor: ₹${String.format("%.2f", vendorPayout)}\n✔ Delivery: ₹${String.format("%.2f", deliveryPayout)}\n✔ Franchise: ₹${String.format("%.2f", franchiseCommission)}\n✔ VDB Platform: ₹${String.format("%.2f", platformFee)}")
            }
        }
    }

    // Simulated actions for multi-role workflows
    fun acceptOrderAsDeliveryPartner(orderId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            vdbDao.updateOrderStatus(orderId, "OUT_FOR_DELIVERY", activeDeliveryPhone, "Ganesh Shinde (VDB Rider)")
        }
    }

    fun completeDelivery(orderId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            vdbDao.updateOrderStatus(orderId, "DELIVERED", activeDeliveryPhone, "Ganesh Shinde (VDB Rider)")
        }
    }

    fun updateOrderStatusAsVendor(orderId: String, newStatus: String) {
        viewModelScope.launch(Dispatchers.IO) {
            vdbDao.updateOrderStatus(orderId, newStatus, "", "")
        }
    }

    fun registerNewBusiness(name: String, category: String, taluka: String, phone: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val b = Business(
                ownerPhone = activeVendorPhone,
                name = name,
                category = category,
                lat = 20.7001 + (Math.random() - 0.5) * 0.05,
                lng = 77.0001 + (Math.random() - 0.5) * 0.05,
                taluka = taluka,
                contactNo = phone,
                kycStatus = "PENDING"
            )
            vdbDao.insertBusiness(b)
        }
    }

    fun verifyBusinessKyc(id: String, verify: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            vdbDao.updateBusinessKyc(id, if (verify) "VERIFIED" else "REJECTED")
        }
    }

    fun addVendorProduct(title: String, desc: String, price: Double, category: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val prod = Product(
                businessId = "B-MOCK-VENDOR-ID",
                businessName = "My Vidarbha Corner",
                title = title,
                description = desc,
                price = price,
                stockQty = 100,
                category = category
            )
            vdbDao.insertProduct(prod)
        }
    }

    fun applyForJob(jobId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            vdbDao.incrementJobApplicant(jobId)
        }
    }

    fun postLocalCommunityUpdate(text: String, area: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val post = CommunityPost(
                authorName = "Anil Deshmukh",
                authorRole = "MSME Owner",
                content = text,
                areaName = area
            )
            vdbDao.insertCommunityPost(post)
        }
    }

    fun upvotePost(id: String) {
        viewModelScope.launch(Dispatchers.IO) {
            vdbDao.likeCommunityPost(id)
        }
    }

    fun addWalletFunds(amount: Double) {
        viewModelScope.launch(Dispatchers.IO) {
            vdbDao.getUserProfileSynchronous(activeCustomerPhone)?.let { profile ->
                vdbDao.updateUserProfile(profile.copy(
                    walletBalance = profile.walletBalance + amount
                ))
            }
        }
    }

    // --- CALL GEMINI ASSIST SERVICE ---
    fun sendUserMessage(msg: String) {
        if (msg.trim().isEmpty()) return
        
        _chatMessages.value = _chatMessages.value + ("User" to msg)
        _isAiLoading.value = true

        viewModelScope.launch {
            try {
                // Compile context from what is stored locally for precise suggestions
                val currentCrops = withContext(Dispatchers.IO) { vdbDao.getCropRates().firstOrNull()?.joinToString("\n") { "${it.cropNameEn} is selling at ₹${it.currentRatePerQuintal}/quintal at ${it.mandiName} Mandi." } ?: "" }
                val currentStores = withContext(Dispatchers.IO) { vdbDao.getAllBusinesses().firstOrNull()?.joinToString("\n") { "Store: ${it.name} (${it.category}), Location: ${it.taluka} Taluka" } ?: "" }
                
                val prompt = """
                    You are the VDB (Vidarbha Digital Bajaar) AI super assistant.
                    Help the local citizen, farmer, vendor or courier in Akola, Maharashtra context.
                    Use local references like Akola, Amravati, Buldhana, Washim, Marigold, Soybeans, cotton, shev bhaji thali.
                    Answer nicely, briefly, incorporating Marathi translations or words if helpful. Focus on action.
                    
                    VDB Current Real-Time Database Index:
                    Crops in Mandi:
                    $currentCrops
                    
                    Registered VDB Stores:
                    $currentStores
                    
                    User query: "$msg"
                """.trimIndent()

                val apiKey = BuildConfig.GEMINI_API_KEY
                val textResponse = if (apiKey.isNotEmpty() && apiKey != "MY_GEMINI_API_KEY") {
                    try {
                        val response = GeminiClient.apiService.generateContent(
                            apiKey = apiKey,
                            request = GeminiRequest(
                                contents = listOf(GeminiContent(parts = listOf(GeminiPart(text = prompt))))
                            )
                        )
                        response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                            ?: "I parsed empty recommendations. Please review in the VDB dashboard."
                    } catch (e: Exception) {
                        // fallback if network fails
                        localRuleAssistant(msg)
                    }
                } else {
                    localRuleAssistant(msg)
                }

                _chatMessages.value = _chatMessages.value + ("AI" to textResponse)
            } catch (e: Exception) {
                _chatMessages.value = _chatMessages.value + ("AI" to "Aapla Maan Sanman! Having technical difficulties, here's our VDB guidance: Try looking at the Mandi Bazaar pricing tab or direct message our helpline.")
            } finally {
                _isAiLoading.value = false
            }
        }
    }

    private fun localRuleAssistant(query: String): String {
        val q = query.lowercase()
        return when {
            q.contains("buy") || q.contains("order") || q.contains("bhojnalaya") || q.contains("shev bhaji") -> {
                "Sure! You can order authentic Khandeshi Shev Bhaji Thali from 'Saraswati Bhojnalaya' (₹140) or pure ghee from 'Vrindavan Dairy' using our 'VDB Food' or 'VDB Quick' tabs. Just add them to your cart and checkout instantly!"
            }
            q.contains("crop") || q.contains("mandi") || q.contains("bajaar") || q.contains("cotton") || q.contains("soybean") -> {
                "Current Mandi Cotton pricing is around ₹7,900/quintal at Amravati Mandi. Soybeans are active at ₹4,250/quintal in Akola Mandi. Check the 'Farmer Market' tab for live booking of seeds, fertilizers, or direct-to-consumer crop listings."
            }
            q.contains("marketing") || q.contains("sell") || q.contains("customer") -> {
                "Marketing recommendation: Set up a VDB Digital Visiting Card. Share it on WhatsApp groups across Maharashtra. Try listing a 5% discount on Cotton Sarees or fresh vegetables on Sundays to boost your VDB local score from 4.2 to 4.8!"
            }
            q.contains("job") || q.contains("work") || q.contains("hiring") -> {
                "VDB Job Portal has active local opportunities! Openings include Field Delivery Executives at VDB Quick (₹15,000/mo) and Farm Supervisor. Go to the 'VDB Jobs' tab to upload your resume."
            }
            else -> {
                "I am here to connect you to all parts of the VDB ecosystem. You can browse local search, order from restaurants, buy agricultural tools, learn digital marketing, or check local job postings. Let me know what you want to achieve today!"
            }
        }
    }

    // --- SEEDING ENGINE ---
    private fun seedInitialDatabase() {
        viewModelScope.launch(Dispatchers.IO) {
            val userCount = vdbDao.getUserProfileSynchronous(activeCustomerPhone)
            if (userCount != null) return@launch // Already seeded

            // 1. Profiles
            vdbDao.insertUserProfile(UserProfile(activeCustomerPhone, "Rajesh Gawande", "rajesh@gmail.com", "CUSTOMER", 5500.00, 250, "mr", "VDB888"))
            vdbDao.insertUserProfile(UserProfile(activeVendorPhone, "Suresh Padhye", "suresh@bhojnalaya.com", "VENDOR", 12000.00, 500, "en", "VDBVNDR", "VERIFIED"))
            vdbDao.insertUserProfile(UserProfile(activeDeliveryPhone, "Ganesh Shinde", "ganesh.delivery@vdb.in", "DELIVERY", 850.00, 100, "hi", "VDBCOURY"))
            vdbDao.insertUserProfile(UserProfile(activeFranchisePhone, "Anandrao Patil", "anandrao.patil@vdb.in", "FRANCHISE", 3500.00, 150, "mr", "VDBFRN99"))
            vdbDao.insertUserProfile(UserProfile("9000000000", "VDB Super Admin", "admin@vdbecosystem.org", "ADMIN", 150000.00, 1000, "en", "ADMNVDB"))

            // 2. Businesses
            val b1 = Business("B-AGRO-FARMS", activeVendorPhone, "Akola Agro Farms", "FARM_PRODUCE", 20.7001, 77.0001, "Akola", "Akola", "9898980001", "27AAAAA1111A1Z1", "VERIFIED", 4.8f)
            val b2 = Business("B-BHOJNALAYA", activeVendorPhone, "Saraswati Bhojnalaya", "RESTAURANT", 20.7022, 76.9950, "Akola", "Akola", "9898980002", "27BBBBB2222B1Z2", "VERIFIED", 4.5f)
            val b3 = Business("B-DAIRY", activeVendorPhone, "Vrindavan Dairy", "GROCERY", 20.6975, 77.0120, "Akola", "Akola", "9898980003", "", "VERIFIED", 4.1f)
            val b4 = Business("B-TECH-SERVICES", activeVendorPhone, "Vidarbha Tech Solutions", "SERVICE", 20.7100, 77.0050, "Akola", "Akola", "9898980004", "", "VERIFIED", 4.9f)
            val b5 = Business("B-CLOTH-BAZAAR", activeVendorPhone, "Panchavati Cloth Bazaar", "E_COMMERCE", 20.7045, 76.9890, "Akola", "Akola", "9898980005", "27CCCCC3333C1Z3", "VERIFIED", 4.6f)

            vdbDao.insertBusiness(b1)
            vdbDao.insertBusiness(b2)
            vdbDao.insertBusiness(b3)
            vdbDao.insertBusiness(b4)
            vdbDao.insertBusiness(b5)

            // 3. Products
            vdbDao.insertProduct(Product("P-SOYBEAN", "B-AGRO-FARMS", "Akola Agro Farms", "Soybean Protection Seeds (50kg Bag)", "High-yield premium Soybeans tailored for Vidarbha humid soils.", 4200.0, 4800.0, 150, "CROP", "organic", "Organic Fertile Stock"))
            vdbDao.insertProduct(Product("P-COTTON", "B-AGRO-FARMS", "Akola Agro Farms", "Organic Cotton Seed (Kapas)", "Special Varalaxmi long staple local cotton seed stock.", 7800.0, 9000.0, 50, "CROP", "organic", "Varalaxmi Strain"))
            vdbDao.insertProduct(Product("P-SHEV-BHAJI", "B-BHOJNALAYA", "Saraswati Bhojnalaya", "Khandeshi Varhadi Shev Bhaji Thali", "Spicy authentic local curry thali served with 2 hot Bhakris, onion and lemon.", 140.0, 160.0, 100, "FOOD", "meal", "Finest Local Spices"))
            vdbDao.insertProduct(Product("P-PITHLA", "B-BHOJNALAYA", "Saraswati Bhojnalaya", "Garlic Pithla Bhakri Combo", "Delectable gram-flour chickpea paste tempered with green chilies, served with Bajra bhakri.", 110.0, 130.0, 80, "FOOD", "meal", "Organic Garlic Tempering"))
            vdbDao.insertProduct(Product("P-GHEE", "B-DAIRY", "Vrindavan Dairy", "Pure Vedic Cow Ghee (1 Litre Pouch)", "Churned using traditional bilona method for rich aroma and taste.", 620.0, 720.0, 200, "GROCERY", "milk", "Bilona Method Churned"))
            vdbDao.insertProduct(Product("P-MILK", "B-DAIRY", "Vrindavan Dairy", "Fresh Buffalo Milk (1 Litre)", "High cream percentage milk delivered in insulated cold bags within 15 mins.", 68.0, 80.0, 400, "GROCERY", "milk", "Zero Preservatives"))
            vdbDao.insertProduct(Product("P-PLUMBER", "B-TECH-SERVICES", "Vidarbha Tech Solutions", "Emergency Pipe Repair Service", "Certified VDB serviceman for plumbing, faucet fixes, and overhead tank cleaning.", 199.0, 199.0, 1, "SERVICE", "plumbing", "VDB Verified Professional"))
            vdbDao.insertProduct(Product("P-TUTOR", "B-TECH-SERVICES", "Vidarbha Tech Solutions", "High School Science Tutor Session", "In-person 1-to-1 session. Physics, Chemistry and Calculus coaching.", 300.0, 300.0, 1, "SERVICE", "tutor", "1 Hour Custom Lesson"))

            // 4. Crop Mandi Prices
            vdbDao.insertCropRate(CropRate("CR1", "सोयाबीन", "Soybean (Akola)", 4250.0, 4180.0, "Akola"))
            vdbDao.insertCropRate(CropRate("CR2", "कापूस (कापूस)", "Kapas / Cotton (Amravati)", 7900.0, 8050.0, "Amravati"))
            vdbDao.insertCropRate(CropRate("CR3", "हळद", "Turmeric (Washim)", 11300.0, 11100.0, "Washim"))
            vdbDao.insertCropRate(CropRate("CR4", "गहू लोकवान", "Wheat Lokwan (Khamgaon)", 2600.0, 2550.0, "Khamgaon"))
            vdbDao.insertCropRate(CropRate("CR5", "ज्वारी (ज्वारी)", "Jowar (Yavatmal)", 3100.0, 3120.0, "Yavatmal"))

            // 5. Job Listings
            vdbDao.insertJob(JobListing("J1", "Field Logistics Executive", "VDB Quick Logistics", "₹15,000 - ₹18,000 / month", "Akola Town", "FULL_TIME", "Deliver groceries and food packets locally within 30 minutes. Bike and valid local license required.", "Android familiarity, local navigation", System.currentTimeMillis(), 4))
            vdbDao.insertJob(JobListing("J2", "Agri Hub Supervisor", "Akola Agro Warehousing", "₹12,000 / month", "Amravati bypass", "PART_TIME", "Verify incoming crop packages, check moisture levels, and update inventory counts on VDB panel.", "Basic computer, agricultural knowledge", System.currentTimeMillis(), 1))

            // 6. Educational Courses
            vdbDao.insertCourse(EducationalCourse("C1", "Digital Visiting Card Mastery", "डिजिटल व्हिजिटिंग कार्ड मास्टरक्लास", "Step-by-step tutorial on how to set up, share, and track hits on your VDB digital listing to attract 10x buyers from Maharashtra.", "Satish Deshpande", "DIGITAL_MARKETING", 45, 4.9f, 5, true))
            vdbDao.insertCourse(EducationalCourse("C2", "Modern Organic Soy Farming", "आधुनिक सोयाबीन सेंद्रिय शेती", "Best practices for soil preparation, sustainable drip irrigation setups, and natural organic bio-fertilizer recipes.", "Dr. Nitin Kadam (Agri Scientist)", "AGRICULTURE", 90, 4.8f, 10, true))

            // 7. Community Posts
            vdbDao.insertCommunityPost(CommunityPost("CO1", "Nivruti Patil", "Farmer", "Great news for cotton growers in Wardha! The cooperative ginning mills just announced active bids up by 3% this week. Make sure to check rates in the VDB pricing portal before locking in private trades.", "Wardha District", 24, 5))
            vdbDao.insertCommunityPost(CommunityPost("CO2", "Meenakshi Joshi", "MSME Owner", "Has anyone registered for the Sunday VDB Agri Entrepreneur training? Session includes free digital visiting card printing template.", "Akola Central", 18, 2))
        }
    }
}
