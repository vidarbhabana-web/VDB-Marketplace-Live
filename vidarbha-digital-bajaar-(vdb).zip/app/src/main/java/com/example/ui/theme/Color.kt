package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Colors
val LightPrimary = Color(0xFFE65C00) // Deep Energetic Saffron
val LightSecondary = Color(0xFF1B5E20) // Forest Organic Green
val LightTertiary = Color(0xFFC0A000) // Polished Marigold Gold
val LightBackground = Color(0xFFFFFBFA) // Premium warm ivory tint
val LightSurface = Color(0xFFFFFFFF)
val LightPrimaryContainer = Color(0xFFFFECE0) // Pastel Saffron Highlight
val LightSecondaryContainer = Color(0xFFE8F5E9) // Pastel Mint Local Box

// Dark Colors
val DarkPrimary = Color(0xFFFF944D)
val DarkSecondary = Color(0xFF81C784)
val DarkTertiary = Color(0xFFFFD54F)
val DarkBackground = Color(0xFF121212)
val DarkSurface = Color(0xFF1E1E1E)
val DarkPrimaryContainer = Color(0xFF4D1F00)
val DarkSecondaryContainer = Color(0xFF1B341D)
