package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "user_profiles")
data class UserProfile(
    @PrimaryKey val phone: String,
    val fullName: String,
    val email: String,
    val role: String, // "CUSTOMER", "VENDOR", "FARMER", "DELIVERY", "FRANCHISE", "ADMIN"
    val walletBalance: Double = 5000.00, // starting balance for easy testing
    val loyaltyPoints: Int = 120,
    val preferredLanguage: String = "en", // "en", "mr", "hi"
    val referralCode: String = "VDB777",
    val kycStatus: String = "VERIFIED" // "PENDING", "VERIFIED", "REJECTED"
)

@Entity(tableName = "businesses")
data class Business(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val ownerPhone: String,
    val name: String, // Stored as a simple name, localized internally or by assistant
    val category: String, // "RESTAURANT", "GROCERY", "E_COMMERCE", "FARM_PRODUCE", "SERVICE"
    val lat: Double,
    val lng: Double,
    val district: String = "Akola", // Akola, Amravati, Buldhana, Washim, Yavatmal, Nagpur, etc.
    val taluka: String = "Akola",
    val contactNo: String,
    val gstNo: String = "",
    val kycStatus: String = "VERIFIED",
    val rating: Float = 4.2f,
    val isActive: Boolean = true,
    val businessCardUrl: String = ""
)

@Entity(tableName = "products")
data class Product(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val businessId: String,
    val businessName: String,
    val title: String,
    val description: String,
    val price: Double,
    val originalPrice: Double = price * 1.2,
    val stockQty: Int,
    val category: String, // "FOOD", "GROCERY", "ELECTRONICS", "CLOTHING", "CROP", "SERVICE"
    val imagePlaceholder: String = "organic", // "meal", "milk", "cotton", "veggie", "plumbing", "tutor"
    val subtext: String = "" // e.g. "Cotton - Varalaxmi", "Plumbing repair per hr"
)

@Entity(tableName = "orders")
data class OrderItem(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val customerPhone: String,
    val customerName: String,
    val businessId: String,
    val businessName: String,
    val itemsSummary: String, // e.g. "2x Paneer Butter Masala, 1x Naan"
    val totalAmount: Double,
    val status: String, // "PENDING", "CONFIRMED", "PREPARING", "OUT_FOR_DELIVERY", "DELIVERED", "CANCELLED"
    val deliveryPartnerPhone: String = "",
    val deliveryPartnerName: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val paymentMethod: String = "WALLET",
    val isSettled: Boolean = false,
    val platformFee: Double = 0.0,
    val vendorShare: Double = 0.0,
    val deliveryShare: Double = 0.0,
    val franchiseShare: Double = 0.0,
    val deliveryLatitude: Double = 20.7001,
    val deliveryLongitude: Double = 77.0001
)

@Entity(tableName = "crop_rates")
data class CropRate(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val cropNameNameMr: String, // localized
    val cropNameEn: String,
    val currentRatePerQuintal: Double,
    val previousRatePerQuintal: Double,
    val mandiName: String, // Akola, Amravati, Khamgaon, Yavatmal, Washim
    val lastUpdated: Long = System.currentTimeMillis()
)

@Entity(tableName = "job_listings")
data class JobListing(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val title: String,
    val businessName: String,
    val salaryText: String,
    val location: String,
    val jobType: String, // "FULL_TIME", "PART_TIME", "DAILY_WAGES", "INTERNSHIP"
    val description: String,
    val requiredSkills: String,
    val postedAt: Long = System.currentTimeMillis(),
    val applicantsCount: Int = 0
)

@Entity(tableName = "educational_courses")
data class EducationalCourse(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val titleEn: String,
    val titleMr: String,
    val description: String,
    val trainer: String,
    val category: String, // "ENTREPRENEURSHIP", "AGRICULTURE", "DIGITAL_MARKETING", "BUSINESS_FINANCE"
    val durationMin: Int = 120,
    val rating: Float = 4.8f,
    val lessonsCount: Int = 12,
    val isFree: Boolean = true
)

@Entity(tableName = "community_posts")
data class CommunityPost(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val authorName: String,
    val authorRole: String, // "Farmer", "MSME Owner", "Local Leader", "Citizen"
    val content: String,
    val areaName: String, // e.g. "Washim District", "Akola Market Row"
    val likesCount: Int = 0,
    val commentsCount: Int = 0,
    val timestamp: Long = System.currentTimeMillis()
)
