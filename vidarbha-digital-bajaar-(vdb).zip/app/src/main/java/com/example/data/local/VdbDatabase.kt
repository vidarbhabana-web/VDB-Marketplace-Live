package com.example.data.local

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow
import java.util.UUID

@Dao
interface VdbDao {
    // --- USER PROFILES ---
    @Query("SELECT * FROM user_profiles ORDER BY phone ASC")
    fun getAllUserProfiles(): Flow<List<UserProfile>>

    @Query("SELECT * FROM user_profiles WHERE phone = :phone LIMIT 1")
    fun getUserProfile(phone: String): Flow<UserProfile?>

    @Query("SELECT * FROM user_profiles WHERE phone = :phone LIMIT 1")
    suspend fun getUserProfileSynchronous(phone: String): UserProfile?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUserProfile(profile: UserProfile)

    @Update
    suspend fun updateUserProfile(profile: UserProfile)

    // --- BUSINESSES ---
    @Query("SELECT * FROM businesses WHERE isActive = 1")
    fun getAllBusinesses(): Flow<List<Business>>

    @Query("SELECT * FROM businesses WHERE category = :category AND isActive = 1")
    fun getBusinessesByCategory(category: String): Flow<List<Business>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBusiness(business: Business)

    @Query("UPDATE businesses SET kycStatus = :status WHERE id = :id")
    suspend fun updateBusinessKyc(id: String, status: String)

    // --- PRODUCTS ---
    @Query("SELECT * FROM products")
    fun getAllProducts(): Flow<List<Product>>

    @Query("SELECT * FROM products WHERE businessId = :businessId")
    fun getProductsByBusiness(businessId: String): Flow<List<Product>>

    @Query("SELECT * FROM products WHERE category = :category")
    fun getProductsByCategory(category: String): Flow<List<Product>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduct(product: Product)

    @Query("DELETE FROM products WHERE id = :id")
    suspend fun deleteProductById(id: String)

    // --- ORDERS ---
    @Query("SELECT * FROM orders ORDER BY createdAt DESC")
    fun getAllOrders(): Flow<List<OrderItem>>

    @Query("SELECT * FROM orders WHERE customerPhone = :phone ORDER BY createdAt DESC")
    fun getOrdersByCustomer(phone: String): Flow<List<OrderItem>>

    @Query("SELECT * FROM orders WHERE businessId = :businessId ORDER BY createdAt DESC")
    fun getOrdersAsVendor(businessId: String): Flow<List<OrderItem>>

    @Query("SELECT * FROM orders WHERE status = 'PENDING' OR status = 'CONFIRMED' OR status = 'PREPARING' OR status = 'OUT_FOR_DELIVERY' ORDER BY createdAt DESC")
    fun getActiveDeliveryOrders(): Flow<List<OrderItem>>

    @Query("SELECT * FROM orders WHERE deliveryPartnerPhone = :deliveryPhone ORDER BY createdAt DESC")
    fun getOrdersByDeliveryPartner(deliveryPhone: String): Flow<List<OrderItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: OrderItem)

    @Query("UPDATE orders SET status = :status, deliveryPartnerPhone = :deliveryPhone, deliveryPartnerName = :deliveryName WHERE id = :id")
    suspend fun updateOrderStatus(id: String, status: String, deliveryPhone: String, deliveryName: String)

    @Query("UPDATE orders SET isSettled = 1 WHERE id = :id")
    suspend fun markOrderAsSettled(id: String)

    // --- CROP RATES ---
    @Query("SELECT * FROM crop_rates ORDER BY lastUpdated DESC")
    fun getCropRates(): Flow<List<CropRate>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCropRate(cropRate: CropRate)

    @Update
    suspend fun updateCropRate(cropRate: CropRate)

    // --- JOBS ---
    @Query("SELECT * FROM job_listings ORDER BY postedAt DESC")
    fun getJobListings(): Flow<List<JobListing>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJob(job: JobListing)

    @Query("UPDATE job_listings SET applicantsCount = applicantsCount + 1 WHERE id = :jobId")
    suspend fun incrementJobApplicant(jobId: String)

    // --- COURSES ---
    @Query("SELECT * FROM educational_courses")
    fun getCourses(): Flow<List<EducationalCourse>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCourse(course: EducationalCourse)

    // --- COMMUNITY FEED ---
    @Query("SELECT * FROM community_posts ORDER BY timestamp DESC")
    fun getCommunityFeed(): Flow<List<CommunityPost>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCommunityPost(post: CommunityPost)

    @Query("UPDATE community_posts SET likesCount = likesCount + 1 WHERE id = :postId")
    suspend fun likeCommunityPost(postId: String)
}

@Database(
    entities = [
        UserProfile::class,
        Business::class,
        Product::class,
        OrderItem::class,
        CropRate::class,
        JobListing::class,
        EducationalCourse::class,
        CommunityPost::class
    ],
    version = 1,
    exportSchema = false
)
abstract class VdbDatabase : RoomDatabase() {
    abstract fun vdbDao(): VdbDao

    companion object {
        @Volatile
        private var INSTANCE: VdbDatabase? = null

        fun getDatabase(context: Context): VdbDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    VdbDatabase::class.java,
                    "vdb_ecosystem_database"
                )
                .fallbackToDestructiveMigration()
                .addCallback(DatabaseSeederCallback())
                .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class DatabaseSeederCallback : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            // Seeds will be triggered here from outside, or manually using standard co-routine launched
            // during app initialization to ensure we run on background scope without taking up block time
        }
    }
}
